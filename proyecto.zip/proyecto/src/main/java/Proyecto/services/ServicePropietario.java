package Proyecto.services;

import java.util.List;

import Proyecto.modelo.Propietario;

public interface ServicePropietario {
	List<Propietario> getListPropietario();
	Propietario crearPropietario(Propietario propietario);
	Propietario ActualizarStockPropietario(Propietario propietario);
	Boolean EliminarPropietario(Long id);
}
