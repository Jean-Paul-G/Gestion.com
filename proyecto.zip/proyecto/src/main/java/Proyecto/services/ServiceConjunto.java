package Proyecto.services;

import java.util.List;

import Proyecto.modelo.Conjunto;

public interface ServiceConjunto {
	List<Conjunto> getListConjunto();
	Conjunto crearConjunto(Conjunto conjunto);
	Conjunto ActualizarStockConjunto(Conjunto conjunto);
	Boolean EliminarConjunto(Long id);
}
