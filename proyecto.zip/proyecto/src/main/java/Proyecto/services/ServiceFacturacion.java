package Proyecto.services;

import java.util.List;

import Proyecto.modelo.Facturacion;

public interface ServiceFacturacion {
	List<Facturacion> getlistfacturacion();
	Facturacion crearFacturacion(Facturacion facturacion);
	Facturacion ActualizarStockFacturacion(Facturacion facturacion);
	Boolean EliminarFacturacion(Long id);
}
