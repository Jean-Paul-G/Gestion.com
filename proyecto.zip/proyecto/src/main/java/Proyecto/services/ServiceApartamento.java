package Proyecto.services;

import Proyecto.modelo.Apartamento;

import java.util.List;

public interface ServiceApartamento {
    List<Apartamento> getlistapartamento();
    Apartamento crearApartamento(Apartamento apartamento);
   Apartamento ActualizarStockApartamento(Apartamento apartamento);
   Boolean EliminarApartamento(Long id);
}