package Proyecto.services;

import java.util.List;

import Proyecto.modelo.Conjuntoxaptxpropietario;

public interface ServiceConjuntoxaptxpropietario {
	List<Conjuntoxaptxpropietario> listarConjuntoxaptxpropietario();
	Conjuntoxaptxpropietario crearConjuntoxaptxpropietario(Conjuntoxaptxpropietario conjuntoxaptxpropietario);
	Conjuntoxaptxpropietario ActualizarStockConjuntoxaptxpropietario(Conjuntoxaptxpropietario conjuntoxaptxpropietario);
	Boolean EliminarConjuntoxaptxpropietario(Long id);
}
