package Proyecto.services;

import java.util.List;

import Proyecto.modelo.Conjuntoxapt;

public interface ServiceConjuntoxapt {
	List<Conjuntoxapt> getlistaConjuntoxapt();
	Conjuntoxapt crearConjuntoxapt(Conjuntoxapt conjuntoxapt);
	Conjuntoxapt ActualizarStockConjuntoxapt(Conjuntoxapt conjuntoxapt);
	Boolean EliminarApartamento(Long id);
}
