package Proyecto.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Conjuntoxapt {
	
	@Id
    @Column(nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
	
	@ManyToOne(fetch = FetchType.LAZY,optional = false)
    @JoinColumn(name = "idconjunto")
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    private Conjunto idconjunto;
	
	@ManyToOne(fetch = FetchType.LAZY,optional = false)
    @JoinColumn(name = "idapt")
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    private Apartamento idapt;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Conjunto getIdconjunto() {
		return idconjunto;
	}

	public void setIdconjunto(Conjunto idconjunto) {
		this.idconjunto = idconjunto;
	}

	public Apartamento getIdapt() {
		return idapt;
	}

	public void setIdapt(Apartamento idapt) {
		this.idapt = idapt;
	}

	public Conjuntoxapt() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Conjuntoxapt(int id, Conjunto idconjunto, Apartamento idapt) {
		super();
		this.id = id;
		this.idconjunto = idconjunto;
		this.idapt = idapt;
	}

}
