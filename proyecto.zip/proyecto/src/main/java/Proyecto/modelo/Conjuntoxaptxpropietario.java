	package Proyecto.modelo;

	import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.FetchType;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
	import javax.persistence.JoinColumn;
	import javax.persistence.ManyToOne;

	import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

	import lombok.AllArgsConstructor;
	import lombok.Builder;
	import lombok.Getter;
	import lombok.NoArgsConstructor;
	import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Conjuntoxaptxpropietario {

		
		@Id
	    @Column(nullable = false)
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private int id;
		
		@ManyToOne(fetch = FetchType.LAZY,optional = false)
	    @JoinColumn(name = "idpropietario")
	    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	    private Propietario idpropietario;

		@ManyToOne(fetch = FetchType.LAZY,optional = false)
	    @JoinColumn(name = "idconxapt")
	    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	    private Conjuntoxapt idconxapt;
		
		@Column(nullable = false)
		private String fecha;

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public Propietario getIdpropietario() {
			return idpropietario;
		}

		public void setIdpropietario(Propietario idpropietario) {
			this.idpropietario = idpropietario;
		}

		public Conjuntoxapt getIdconxapt() {
			return idconxapt;
		}

		public void setIdconxapt(Conjuntoxapt idconxapt) {
			this.idconxapt = idconxapt;
		}

		public String getFecha() {
			return fecha;
		}

		public void setFecha(String fecha) {
			this.fecha = fecha;
		}

		public Conjuntoxaptxpropietario() {
			super();
			// TODO Auto-generated constructor stub
		}

		public Conjuntoxaptxpropietario(int id, Propietario idpropietario, Conjuntoxapt idconxapt, String fecha) {
			super();
			this.id = id;
			this.idpropietario = idpropietario;
			this.idconxapt = idconxapt;
			this.fecha = fecha;
		}
}

