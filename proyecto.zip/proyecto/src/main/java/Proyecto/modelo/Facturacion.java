package Proyecto.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Facturacion {
	
	@Id
    @Column(nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

	@Column(nullable = false)
	private String fechapago;
	
	@Column(nullable = false)
	private String fechafactura;
	
	@Column(nullable = false)
	private boolean cancelado;
	
	@Column(nullable = false)
	private int monto;
	
	@Column(nullable = false)
	private String url;
	
	@ManyToOne(fetch = FetchType.LAZY,optional = false)
    @JoinColumn(name = "idconxaptxprop ")
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    private Conjuntoxaptxpropietario idconxaptxprop ;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFechapago() {
		return fechapago;
	}

	public void setFechapago(String fechapago) {
		this.fechapago = fechapago;
	}

	public String getFechafactura() {
		return fechafactura;
	}

	public void setFechafactura(String fechafactura) {
		this.fechafactura = fechafactura;
	}

	public boolean isCancelado() {
		return cancelado;
	}

	public void setCancelado(boolean cancelado) {
		this.cancelado = cancelado;
	}

	public int getMonto() {
		return monto;
	}

	public void setMonto(int monto) {
		this.monto = monto;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Conjuntoxaptxpropietario getIdconxaptxprop() {
		return idconxaptxprop;
	}

	public void setIdconxaptxprop(Conjuntoxaptxpropietario idconxaptxprop) {
		this.idconxaptxprop = idconxaptxprop;
	}

	public Facturacion() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Facturacion(int id, String fechapago, String fechafactura, boolean cancelado, int monto, String url,
			Conjuntoxaptxpropietario idconxaptxprop) {
		super();
		this.id = id;
		this.fechapago = fechapago;
		this.fechafactura = fechafactura;
		this.cancelado = cancelado;
		this.monto = monto;
		this.url = url;
		this.idconxaptxprop = idconxaptxprop;
	}
}
