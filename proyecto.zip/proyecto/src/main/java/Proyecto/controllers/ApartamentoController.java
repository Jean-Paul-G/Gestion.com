package Proyecto.controllers;

import Proyecto.modelo.Apartamento;
import Proyecto.servicesimp.ApartamentoImp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE})
@RequestMapping(path = "api/apartamento")
public class ApartamentoController {

    @Autowired
    private ApartamentoImp serviceApartamento;

    @GetMapping
    public ResponseEntity<List<Apartamento>> listarApartamentos() {
        List<Apartamento> lista = serviceApartamento.getListarApartamento();
        return ResponseEntity.ok(lista);
    }

    @PostMapping
    public ResponseEntity<?> crearApartamento(@RequestBody Apartamento apartamento) {
        return new ResponseEntity<>(serviceApartamento.crearApartamento(apartamento), HttpStatus.CREATED);
    }
    
    @PutMapping
    public ResponseEntity<Apartamento> ActualizarStock (@RequestBody Apartamento apartamento){
    	Apartamento actualizar = serviceApartamento.ActualizarStockApartamento(apartamento);
    	 return ResponseEntity.ok(actualizar);
    }
    
    @DeleteMapping(value = "/{id}")
    public ResponseEntity<String> EliminarApartamento(@PathVariable("id") Long id){
        if(id > 0){
            if( serviceApartamento.EliminarApartamento(id)){
                 return ResponseEntity.ok().body("Eliminado");
            }
        }
        return ResponseEntity.notFound().build();
    }
}