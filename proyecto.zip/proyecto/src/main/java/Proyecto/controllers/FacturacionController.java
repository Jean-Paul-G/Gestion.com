package Proyecto.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import Proyecto.modelo.Facturacion;
import Proyecto.servicesimp.FacturacionImp;

@RestController
@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE})
@RequestMapping(path = "api/facturacion")
public class FacturacionController {
	
	@Autowired
    private FacturacionImp serviceFacturacion;
	
	@GetMapping
    public ResponseEntity<List<Facturacion>> listarFacturacion(){
		List<Facturacion> lista = serviceFacturacion.getlistarFacturacion();
		return ResponseEntity.ok(lista);
	}
	
	@PostMapping
    public ResponseEntity<?> crearFacturacion(@RequestBody Facturacion facturacion) {
		 return new ResponseEntity<>(serviceFacturacion.crearFacturacion(facturacion), HttpStatus.CREATED);
	}
	
	 @PutMapping
	    public ResponseEntity<Facturacion> ActualizarStock (@RequestBody Facturacion facturacion) {
		 Facturacion actualizar = serviceFacturacion.ActualizarStockFacturacion(facturacion);
		 return ResponseEntity.ok(actualizar);
	 }
	 
	 @DeleteMapping(value = "/{id}")
	    public ResponseEntity<String> EliminarFacturacion(@PathVariable("id") Long id){
		 if(id > 0){
			 if(serviceFacturacion.EliminarFacturacion(id)) {
				 return ResponseEntity.ok().body("Eliminado");
			 }
		 }
		 return ResponseEntity.notFound().build();
	 }

}
