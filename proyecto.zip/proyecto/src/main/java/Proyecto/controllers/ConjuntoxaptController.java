package Proyecto.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import Proyecto.modelo.Conjuntoxapt;
import Proyecto.servicesimp.ConjuntoxaptImp;

@RestController
@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE})
@RequestMapping(path = "api/conjuntoxapt")
public class ConjuntoxaptController {

	@Autowired
	private ConjuntoxaptImp ServiceConjuntoxapt;
	
	@GetMapping
    public ResponseEntity<List<Conjuntoxapt>> listarConjuntoxapt(){
		List<Conjuntoxapt> lista = ServiceConjuntoxapt.getlistarConjuntoxapt();
		return ResponseEntity.ok(lista);
	}
	
	@PostMapping
    public ResponseEntity<?> crearConjuntoxapt(@RequestBody Conjuntoxapt conjuntoxapt){
		 return new ResponseEntity<>(ServiceConjuntoxapt.crearConjuntoxapt(conjuntoxapt), HttpStatus.CREATED);
	}
	
	@PutMapping
	public ResponseEntity<Conjuntoxapt> ActualizarStock(@RequestBody Conjuntoxapt conjuntoxapt){
		Conjuntoxapt actualizar = ServiceConjuntoxapt.ActualizarStockConjuntoxapt(conjuntoxapt);
		return ResponseEntity.ok(actualizar);
	}
	
	 @DeleteMapping(value = "/{id}")
	    public ResponseEntity<String> EliminarConjuntoxapt(@PathVariable("id") Long id){
	        if(id > 0){
	            if (ServiceConjuntoxapt.EliminarConjuntoxapt(id)){
                 return ResponseEntity.ok().body("Eliminado");
            }
        }
        return ResponseEntity.notFound().build();
    }
}
