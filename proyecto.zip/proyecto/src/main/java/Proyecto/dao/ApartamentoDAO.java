package Proyecto.dao;

import Proyecto.modelo.Apartamento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ApartamentoDAO  extends JpaRepository <Apartamento, Integer> {

}
//realizar filtros para validar registros ya existentes en el DB