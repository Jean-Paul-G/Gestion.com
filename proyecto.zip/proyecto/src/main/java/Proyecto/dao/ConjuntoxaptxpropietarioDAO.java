package Proyecto.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import Proyecto.modelo.Conjuntoxaptxpropietario;

public interface ConjuntoxaptxpropietarioDAO  extends JpaRepository <Conjuntoxaptxpropietario, Integer>{

}
