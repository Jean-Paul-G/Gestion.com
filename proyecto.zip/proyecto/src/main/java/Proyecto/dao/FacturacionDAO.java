package Proyecto.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import Proyecto.modelo.Facturacion;

public interface FacturacionDAO extends JpaRepository <Facturacion, Integer>{

}
