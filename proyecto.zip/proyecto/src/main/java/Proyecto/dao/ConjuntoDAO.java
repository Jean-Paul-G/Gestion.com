package Proyecto.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import Proyecto.modelo.Conjunto;

@Repository
public interface ConjuntoDAO extends JpaRepository<Conjunto, Integer> {
	
	

}
