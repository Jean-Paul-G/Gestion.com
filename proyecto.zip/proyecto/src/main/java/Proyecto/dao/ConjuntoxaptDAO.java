package Proyecto.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import Proyecto.modelo.Conjuntoxapt;

@Repository
public interface ConjuntoxaptDAO  extends JpaRepository <Conjuntoxapt, Integer>{

}
