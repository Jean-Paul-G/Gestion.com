package Proyecto.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import Proyecto.modelo.Propietario;

public interface PropietarioDAO extends JpaRepository <Propietario, Integer>{

}
