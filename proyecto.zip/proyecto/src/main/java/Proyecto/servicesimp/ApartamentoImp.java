package Proyecto.servicesimp;

import Proyecto.dao.ApartamentoDAO;
import Proyecto.modelo.Apartamento;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;
import java.util.Optional;

@Service
public class ApartamentoImp  {

    @Autowired
    private ApartamentoDAO getDao;

    public List<Apartamento> getListarApartamento() {
        return getDao.findAll();
    }

    public Apartamento crearApartamento(Apartamento apartamento) {
        if (apartamento != null) {
            return getDao.save(apartamento);
        }
        return null;
    }
    
   public Apartamento ActualizarStockApartamento(Apartamento apartamento) {
	   Apartamento apartamentoBD = getDao.getReferenceById(apartamento.getId());
    	if (apartamento != null && apartamento.getId()!= 0) {
                return getDao.save(apartamentoBD);
    		}
		return null;
   }
   
   public Boolean EliminarApartamento(long id) {
       if(id > 0){
     	  Optional<Apartamento> apartamentoBD = getDao.findById((int) id);
         if(apartamentoBD != null){
             getDao.deleteById((int) id);
              return true;
         }
       }
        return false;
 }
  
}