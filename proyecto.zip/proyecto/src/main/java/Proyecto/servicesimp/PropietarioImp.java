package Proyecto.servicesimp;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Proyecto.dao.PropietarioDAO;
import Proyecto.modelo.Propietario;

@Service
public class PropietarioImp {

	@Autowired
	private PropietarioDAO getDao;
	
	public List<Propietario> getlistarPropietario(){
		return getDao.findAll();
	}
	
	public Propietario crearPropietario(Propietario propietario) {
		if (propietario != null) {
			return getDao.save(propietario);
		}
		return null;
	}
	
	public Propietario ActualizarStockPropietario(Propietario propietario) {
		Propietario propietarioDB = getDao.getReferenceById(propietario.getId());
		if (propietario != null && propietario.getId() != 0) {
			return getDao.save(propietarioDB);
		}
		return null;
	}
	
	public Boolean EliminarPropietario(long id) {
		if (id > 0){
			Optional<Propietario> propietarioDB = getDao.findById((int)id);
			if (propietarioDB != null) {
				getDao.deleteById((int) id);
				return true;
			}
		}
		return false;
	}
}
