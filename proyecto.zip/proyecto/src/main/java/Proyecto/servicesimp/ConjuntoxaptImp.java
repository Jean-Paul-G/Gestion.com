package Proyecto.servicesimp;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Proyecto.dao.ConjuntoxaptDAO;
import Proyecto.modelo.Conjuntoxapt;

@Service
public class ConjuntoxaptImp {

	@Autowired
    private ConjuntoxaptDAO getDao;
	
	public List<Conjuntoxapt> getlistarConjuntoxapt() {
		return getDao.findAll();
	}
	
	public Conjuntoxapt crearConjuntoxapt(Conjuntoxapt conjuntoxapt) {
		if (conjuntoxapt != null) {
            return getDao.save(conjuntoxapt);
		}
		return null;
	}
	
	public Conjuntoxapt ActualizarStockConjuntoxapt(Conjuntoxapt conjuntoxapt) {
		Conjuntoxapt conjuntoxaptBD = getDao.getReferenceById(conjuntoxapt.getId());
		if (conjuntoxapt != null && conjuntoxapt.getId()!= 0) {
			return getDao.save(conjuntoxaptBD);
		}
		return null;
	}
	
	public Boolean EliminarConjuntoxapt(long id) {
	       if(id > 0){
	      	  Optional <Conjuntoxapt> conjuntoxaptBD = getDao.findById((int) id);
	          if (conjuntoxaptBD != null){
             getDao.deleteById((int) id);
              return true;
         }
       }
        return false;
	}
}
