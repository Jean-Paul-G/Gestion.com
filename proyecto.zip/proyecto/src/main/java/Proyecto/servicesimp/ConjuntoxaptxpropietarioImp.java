package Proyecto.servicesimp;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Proyecto.dao.ConjuntoxaptxpropietarioDAO;
import Proyecto.modelo.Conjuntoxaptxpropietario;

@Service
public class ConjuntoxaptxpropietarioImp {
	
	@Autowired
    private ConjuntoxaptxpropietarioDAO getDao;

	public List<Conjuntoxaptxpropietario> getlistarConjuntoxaptxpropietario(){
		return getDao.findAll();
	}
	
	public Conjuntoxaptxpropietario crearConjuntoxaptxpropietario(Conjuntoxaptxpropietario conjuntoxaptxpropietario){
		if (conjuntoxaptxpropietario != null) {
			return getDao.save(conjuntoxaptxpropietario);
		}
		return null;
	}
	
	public Conjuntoxaptxpropietario ActualizarStockConjuntoxaptxpropietario(Conjuntoxaptxpropietario conjuntoxaptxpropietario) {
		Conjuntoxaptxpropietario conjuntoxaptxpropietarioDB = getDao.getReferenceById(conjuntoxaptxpropietario.getId());
		if (conjuntoxaptxpropietario != null && conjuntoxaptxpropietario.getId()!= 0) {
			return getDao.save(conjuntoxaptxpropietarioDB);
		}
		return null;
	}
	
	public Boolean EliminarConjuntoxaptxpropietario(long id) {
	       if(id > 0){
		      	  Optional <Conjuntoxaptxpropietario> conjuntoxaptxpropietarioDB = getDao.findById((int) id);
		      	  if (conjuntoxaptxpropietarioDB != null){
             getDao.deleteById((int) id);
              return true;
         }
       }
        return false;
	}
}
