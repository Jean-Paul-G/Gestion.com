package Proyecto.servicesimp;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Proyecto.dao.ConjuntoDAO;
import Proyecto.modelo.Conjunto;

@Service
public class ConjuntoImp {
	
	@Autowired
	private ConjuntoDAO getDao;
	
	public List<Conjunto> getlistarConjunto(){
		return getDao.findAll();
	}
	
	public Conjunto crearConjunto(Conjunto conjunto) {
		if (conjunto != null) {
			return getDao.save(conjunto);
		}
		return null;
	}

	public Conjunto ActualizarStockConjunto(Conjunto conjunto) {
		Conjunto conjuntoBD = getDao.getReferenceById(conjunto.getId());
		if (conjunto != null && conjunto.getId()!= 0) {
			return getDao.save(conjuntoBD);
		}
		return null;
	}
	
	public Boolean EliminarConjunto (long id) {
		if (id > 0){
			Optional<Conjunto> conjuntoBD = getDao.findById((int)id);
			if (conjuntoBD != null) {
				getDao.deleteById((int) id);
				return true;
			}
		}
		return false;
	}
}
