package Proyecto.servicesimp;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Proyecto.dao.FacturacionDAO;
import Proyecto.modelo.Facturacion;

@Service
public class FacturacionImp {
	
	 @Autowired
	    private FacturacionDAO getDao;
	 
	 public List<Facturacion> getlistarFacturacion(){
		 return getDao.findAll();
	 }
	 
	 public Facturacion crearFacturacion(Facturacion facturacion) {
		 if (facturacion != null) {
			 return getDao.save(facturacion);
		 }
		 return null;
	 }
	 
	 public Facturacion ActualizarStockFacturacion(Facturacion facturacion) {
		 Facturacion facturacionDB = getDao.getReferenceById(facturacion.getId());
		 if (facturacion != null && facturacion.getId()!= 0) {
			 return getDao.save(facturacionDB);
		 }
		 return null;
	 }
	 
	 public Boolean EliminarFacturacion(long id) {
		 if(id > 0){
	     	  Optional<Facturacion> facturacionDB = getDao.findById((int) id);
	     	  if (facturacionDB != null) {
	     		 getDao.deleteById((int) id);
	              return true;
	     	  }
		 }
		 return false;
	 }
}
